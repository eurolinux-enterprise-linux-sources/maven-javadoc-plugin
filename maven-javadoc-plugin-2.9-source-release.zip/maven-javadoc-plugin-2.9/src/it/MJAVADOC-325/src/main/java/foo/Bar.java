package foo;

public class Bar {}