package test;

/**
 * this is a simple test class
 */
public class TestClass
{

}
