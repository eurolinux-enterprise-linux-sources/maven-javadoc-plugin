package org.apache.maven.plugins.mjavadoc.it.moda;

/**
 * Hello world!
 *
 * @.foo    A 1st custom javadoc tag.
 * @author  Me
 * @version 1st
 * @.bar    A 2nd custom javadoc tag.
 * @see     String#startsWith(String)
 */
public class App
{
    public static void main( final String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
