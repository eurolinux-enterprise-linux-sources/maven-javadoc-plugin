package org.apache.maven.plugins.mjavadoc.it.moda;

/**
 * Hello world!
 *
 */
public class App
{
    public static void main( final String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
