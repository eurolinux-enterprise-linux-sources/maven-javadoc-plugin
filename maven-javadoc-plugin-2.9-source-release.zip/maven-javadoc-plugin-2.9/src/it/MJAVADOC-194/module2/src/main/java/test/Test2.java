package test;

/**
 */
public class Test2
{
	/**
	 * Default constructor.
	 */
	public Test2()
	{
		super();
	}

}