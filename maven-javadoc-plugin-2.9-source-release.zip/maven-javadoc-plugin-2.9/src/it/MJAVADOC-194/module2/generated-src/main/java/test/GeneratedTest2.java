package test;

/**
 */
public class GeneratedTest2
{
	/**
	 * Default constructor.
	 */
	public GeneratedTest2()
	{
		super();
	}

}