package test;

/**
 */
public class Test1
{
	/**
	 * Default constructor.
	 */
	public Test1()
	{
		super();
	}

}