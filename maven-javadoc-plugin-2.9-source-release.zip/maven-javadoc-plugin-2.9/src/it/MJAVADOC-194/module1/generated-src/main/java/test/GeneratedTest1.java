package test;

/**
 */
public class GeneratedTest1
{
	/**
	 * Default constructor.
	 */
	public GeneratedTest1()
	{
		super();
	}

}