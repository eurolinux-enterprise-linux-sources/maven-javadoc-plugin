package com.mycompany.myapp;

/**
 * Hello world!
 *
 * <img src="doc-files/maven-feather.png" alt="Maven"/>
 */
public class App
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
    
    
    private static void main2()
    {
        System.out.println( "Hello World!" );
    }
}
