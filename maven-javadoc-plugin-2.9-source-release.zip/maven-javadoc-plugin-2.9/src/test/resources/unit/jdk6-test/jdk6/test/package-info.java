/**
 * <b>Test the package-info</b>
 */
package jdk6.test;
