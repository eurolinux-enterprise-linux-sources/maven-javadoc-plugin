/**
 * <b>Test the package-info</b>
 */
package jdk5.test;
